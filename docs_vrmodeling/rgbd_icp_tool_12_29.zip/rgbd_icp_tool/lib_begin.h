#ifdef RGBD_ICP_TOOL_EXPORTS
#	define CGV_EXPORTS
#endif

#include <cgv/config/lib_begin.h>
